import {useState, useEffect} from 'react'
import './App.css';

function App() {

  const [pokeList, setPokeList] = useState([]);

  useEffect( () => {

    fetch("https://pokeapi.co/api/v2/pokemon?limit=1000")
    .then ( (res) => {
      return res.json()
    }).then ((result) => {
      console.log(result)
      setPokeList(result.results)
    }).catch ((err) => {
      console.log(err)
    })

  },[])

  return (
    <div className="App">

      {
      
        pokeList.map((poke) => (
          <div>
            <h1>{poke.name}</h1>
          </div>
        ))
      }
    </div>
  );
}

export default App;
