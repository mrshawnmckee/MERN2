import React, {useState} from 'react'
import './App.css';

function App() {
  const [newToDo, setNewToDo] = useState("");
  const [todos, setTodos] = useState([]);

  const handleNewTodoSubmit = (e) => {
    e.preventDefault();

    if(newToDo.length === 0) {    //This makes sure an empty item cannot be entered with the add button
      return;                     // if nothing is entered, return nothing
    }

    // This is the start for the line through and checkbox part of the assignment
    // turning the data into an array/object from a string
    const todoItem = {
      text:newToDo, 
      complete:false
    }

    setTodos([...todos, todoItem])   //...todos; spread operator to remember what is already there, newTodo to add
    setNewToDo("")  //makes newToDo empty in state, with value={NewToDo} later on input makes the input box empty after button click
  }

  const handleDelete = (deleteAtTheIndex) => {     //This is the function for deleting the object from the todo list
    const filteredTodo = todos.filter((todo, i) => {
      return i !== deleteAtTheIndex;    //if it is not equal to the one to be deleted, keep it in the array
    });
    setTodos(filteredTodo);   //This calls the function to delete the item at index
  };
  
  const handleToggle = (idx) =>{    //This will return the todos unchanged except the on that has been changed
    const updateTodos = todos.map((todo, i) => {
      if (idx === i) {
        todo.complete = !todo.complete;   //!todo.complete changes the valur=e to the reverse of what it is
      }
      return todo;
    });

    setTodos(updateTodos);      //Without this the checkbox will not work at all
  }



  return (
    <div style={{textAlign:"center"}}>
      <form onSubmit={(e)=>{
        handleNewTodoSubmit(e);
      }}>
        <input onChange ={(e) =>{
          setNewToDo(e.target.value);
        }} type="text" 
        value={newToDo}     //with the setNewToDO(""), makes the input box empty after button click
        />
        <div>
          <button>Add</button>
        </div>
      </form> 
      {/* Turn the array into a list to be printed out onto the screen */}
      {todos.map((todo, i) =>{
          const todoClasses = [];   //creating empty array for line through

          if (todo.complete) {
            todoClasses.push("line-through"); //this creates the condition for line-through, used with the 
          }                                   //line-through class created in App.css file

          return (
          <div key={i}>     {/*This index number avoids the error for unique key */}   
            {/*todoclasses.join to help with the process of crossing out the item */}
            <span className={todoClasses.join(" ")}>{todo.text}</span>
            <input onChange={(e) =>{
              handleToggle(i);          {/*This changes the property of the checkbox from false to true or back */}
            }}    checked={todo.complete} type="checkbox" /> {/*Add checkbox and checked tells the complete property's state*/}
            {/*This button and the associated function handles deleting the item from the todo list*/}
            <button 
              onClick={(e) =>{
                handleDelete(i)
              }}
              
              style={{marginLeft:"10px"}}     //Adds space in between list item and delete button
              >
              Delete
            </button>

          </div>
          )
        })
      }
    </div>
  );
}

export default App;
